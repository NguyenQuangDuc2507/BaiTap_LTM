﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;

namespace BTGiuaKi_ThayAn
{
    public partial class Forgot_Password : Form
    {
        public Forgot_Password()
        {
            InitializeComponent();
        }

        private void bt_resetPassword_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=ADMIN\SQLEXPRESS;Initial Catalog=K63_QLUser;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("Select Count(*) From tb_User where Email ='" + tb_email.Text + "'", con);
            SqlDataReader sdr = cmd.ExecuteReader();
           /* try {*/ 
            if (sdr.Read())
            {

                /*Messgasebox.show("Mật khẩu của bạn là:"+ sdr.GetValue(1).ToString());*/
                label_thongbao.Text = "Mật khẩu của bạn là:" + sdr.GetValue(1).ToString();

                /*Trở về form đăng nhập*/
                this.Close();
                Form1 frm = new Form1();
                frm.Show();
            }
            else
            {
                MessageBox.Show("Không tìm thấy Email hoặc Email chưa được đăng ký!");
            }
            /*}
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }*/
            
        }
    }
}
