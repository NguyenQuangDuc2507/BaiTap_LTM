﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient; /*/*import thêm system.data.sqlclient*/

namespace BTGiuaKi_ThayAn
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void bt_login_Click(object sender, EventArgs e)
        {
            /*tạo chuỗi kết nối với db*/
            SqlConnection con = new SqlConnection(@"Data Source=ADMIN\SQLEXPRESS;Initial Catalog=K63_QLUser;Integrated Security=True");
            /*string v = "Select Count(*) From tb_Login where Username ='" + tb_username.Text +
                "'and Password ='" + tb_password.Text + "'", con;
            SqlDataAdapter sda = new SqlDataAdapter(v);*/
            SqlDataAdapter sda = new SqlDataAdapter("Select Count(*) From tb_User where Username ='" + tb_username.Text +
                "'and Password ='" + tb_password.Text + "'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            /* */
            if(dt.Rows[0][0].ToString() == "1")
            {
                this.Hide();
                /*Chuyển sang form Main*/
                Main c = new Main();
                c.Show();
            }
            else
            {
                /* Hiển thị lỗi khi đăng nhập sai*/
                MessageBox.Show("Tên đăng nhập hoặc mật khẩu không chính xác. Vui lòng thử lại");
            }

        }

        private void lb_dki_Click(object sender, EventArgs e)
        {
            this.Hide();
            New_account nac = new New_account();
            nac.Show();
        }

        private void lb_quenpw_Click(object sender, EventArgs e)
        {
            this.Hide();
            Forgot_Password fgp = new Forgot_Password();
            fgp.Show();
        }
    }
}
