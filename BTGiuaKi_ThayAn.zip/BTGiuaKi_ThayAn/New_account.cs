﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient; /*import thêm system.data.sqlclient*/

namespace BTGiuaKi_ThayAn
{
    public partial class New_account : Form
    {   
        /*Khai báo chuỗi kết nối của việc đăng ký người dùng trong database */
        /*string ConnectionString = @"Data Source=ADMIN\SQLEXPRESS;Initial Catalog=K63_QLUser;Integrated Security=True";*/
        public New_account()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (tb_Email.Text == "" || tb_Username.Text == "" || tb_Password.Text == "")
                MessageBox.Show("Bạn chưa nhập thông tin.Vui lòng nhập thông tin!");
            /*Nếu 1 trong 3 tb rỗng thì báo lỗi*/
            else
                if (tb_Password.Text != tb_Confirm.Text)
                MessageBox.Show("Mật khẩu xác nhận không chính xác. Vui lòng nhập lại!");
            /*Mật khẩu và xác nhận mật khẩu không trùng nhau*/
            else
            {   
                /*Tạo sqlconnection*/
                SqlConnection con = new SqlConnection(@"Data Source=ADMIN\SQLEXPRESS;Initial Catalog=K63_QLUser;Integrated Security=True");
                
                    con.Open();

                    SqlCommand sqm = new SqlCommand("newUser", con);
                    sqm.CommandType = CommandType.StoredProcedure;
                    sqm.Parameters.AddWithValue("@Email", tb_Email.Text.Trim());
                    sqm.Parameters.AddWithValue("@Username", tb_Username.Text.Trim());
                    sqm.Parameters.AddWithValue("@Password", tb_Password.Text.Trim());
                    sqm.ExecuteNonQuery();

                    MessageBox.Show("Đăng ký thành công");
                    duyetAccount();
                    this.Hide();
                    Form1 login = new Form1();
                    login.Show();
            }
        }
        
        void duyetAccount()
        {
            tb_Email.Text = tb_Username.Text = tb_Password.Text = tb_Confirm.Text = "";
        }
    }
}
